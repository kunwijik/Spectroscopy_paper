# -*- coding: utf-8 -*-
 
 # Copyright (c) 2008 - 2014 Detlev Offenbach <detlev@die-offenbachs.de>
 #
 
"""
Package containing the mdi area view manager plugin.
""" 
