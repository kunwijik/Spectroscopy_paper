# -*- coding: utf-8 -*-

# Copyright (c) 2006 - 2014 Detlev Offenbach <detlev@die-offenbachs.de>
#

"""
Package implementing some special GUI elements.

They extend or ammend the standard elements as found in QtGui.
"""
