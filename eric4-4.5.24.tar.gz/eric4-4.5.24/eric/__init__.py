# -*- coding: utf-8 -*-

# Copyright (c) 2003 - 2014 Detlev Offenbach <detlev@die-offenbachs.de>
#

"""
Package implementing the eric4 Python IDE (version 4.5).

To get more information about eric4 please see the 
<a href="http://eric-ide.python-projects.org/index.html">eric web site</a>.
"""
